# universalConverter
a tool for converting different data table formats (text/strings) in other ones. goals: fast, intuitive, general, 
